import os
import shutil
import zipfile
import time
import subprocess
import platform
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog

class BlasterFile:
    def __init__(self, root):
        self.root = root
        self.root.title("BlasterArchiver")
        self.root.geometry("1100x650")
        self.root.configure(bg="#121212")

        self.vault_path = os.path.join(os.path.expanduser("~"), "Vault")
        self.password_file = os.path.join(self.vault_path, "vault_pass.txt")

        self.crear_vault_si_no_existe()

        # --- ESTILO DARK ---
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview",
                        background="#1e1e1e",
                        foreground="white",
                        fieldbackground="#1e1e1e",
                        borderwidth=0,
                        font=("Segoe UI", 10))
        style.map("Treeview", background=[('selected', '#333333')])

        style.configure("Treeview.Heading",
                        background="#2d2d2d",
                        foreground="white",
                        relief="flat",
                        font=("Segoe UI", 9, "bold"))
        style.map("Treeview.Heading", background=[('active', '#404040')])

        self.ruta_actual = tk.StringVar(value=os.path.expanduser("~"))
        self.busqueda = tk.StringVar()
        self.busqueda.trace("w", lambda *args: self.actualizar_lista())

        # --- INTERFAZ ---
        self.paned = tk.PanedWindow(root, orient=tk.HORIZONTAL, bg="#121212", sashwidth=2)
        self.paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.frame_lat = tk.Frame(self.paned, bg="#181818")
        self.tree_dir = ttk.Treeview(self.frame_lat)
        self.tree_dir.heading("#0", text=" DIRECTORIOS", anchor='w')
        self.tree_dir.pack(fill=tk.BOTH, expand=True)
        self.tree_dir.bind("<<TreeviewSelect>>", self.on_tree_select)
        self.paned.add(self.frame_lat, width=220)

        self.frame_main = tk.Frame(self.paned, bg="#121212")
        self.paned.add(self.frame_main)

        frame_nav = tk.Frame(self.frame_main, bg="#121212")
        frame_nav.pack(fill=tk.X, pady=5)

        tk.Label(frame_nav, text="🔍", bg="#121212", fg="#5cb85c").pack(side=tk.LEFT, padx=5)
        self.entry_search = tk.Entry(frame_nav, textvariable=self.busqueda,
                                     bg="#252525", fg="white", insertbackground="white")
        self.entry_search.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)

        cols = ("nombre", "tamaño", "fecha")
        self.tabla = ttk.Treeview(self.frame_main, columns=cols, show="headings")
        self.tabla.heading("nombre", text="NOMBRE")
        self.tabla.heading("tamaño", text="TAMAÑO")
        self.tabla.heading("fecha", text="FECHA")

        self.tabla.column("nombre", width=400)
        self.tabla.column("tamaño", width=100, anchor="center")
        self.tabla.column("fecha", width=150, anchor="center")

        self.tabla.pack(fill=tk.BOTH, expand=True, padx=5)
        self.tabla.bind('<Double-1>', self.on_doble_clic)

        btn_frame = tk.Frame(self.frame_main, bg="#121212")
        btn_frame.pack(fill=tk.X, pady=15)

        self.crear_boton(btn_frame, "📄 Crear", self.crear).pack(side=tk.LEFT, padx=2)
        self.crear_boton(btn_frame, "🗑️ Borrar", self.borrar).pack(side=tk.LEFT, padx=2)
        self.crear_boton(btn_frame, "🗜️ ZIP", self.hacer_zip).pack(side=tk.LEFT, padx=2)

        self.crear_boton(btn_frame, "📦 Guardar en MegaCarpetas", self.mover_a_vault).pack(side=tk.LEFT, padx=10)
        self.crear_boton(btn_frame, "🔐 Abrir MegaCarpeta", self.abrir_vault).pack(side=tk.LEFT, padx=2)

        self.cargar_arbol_inicial()
        self.actualizar_lista()

    # ---------------- VAULT ----------------

    def crear_vault_si_no_existe(self):
        if not os.path.exists(self.vault_path):
            os.makedirs(self.vault_path)
            os.system(f'attrib +h "{self.vault_path}"')

            password = simpledialog.askstring("Vault", "Creá una contraseña:", show="*")
            if password:
                with open(self.password_file, "w") as f:
                    f.write(password)

    def mover_a_vault(self):
        item = self.tabla.focus()
        if not item:
            messagebox.showwarning("Atención", "Seleccioná un archivo.")
            return

        nombre = self.tabla.item(item, "values")[0][2:]
        origen = os.path.join(self.ruta_actual.get(), nombre)
        destino = os.path.join(self.vault_path, nombre)

        try:
            shutil.move(origen, destino)
            messagebox.showinfo("Vault", "Archivo guardado en Vault.")
            self.actualizar_lista()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def abrir_vault(self):
        clave = simpledialog.askstring("Vault", "Ingresá contraseña:", show="*")
        if not clave:
            return

        try:
            with open(self.password_file, "r") as f:
                guardada = f.read()

            if clave == guardada:
                os.system(f'explorer "{self.vault_path}"')
            else:
                messagebox.showerror("Error", "Contraseña incorrecta.")
        except:
            messagebox.showerror("Error", "Vault no configurado.")

    # ---------------- RESTO DEL GESTOR ----------------

    def crear_boton(self, parent, texto, comando):
        return tk.Button(parent, text=texto, command=comando,
                         bg="#333333", fg="white", relief="flat")

    def actualizar_lista(self):
        self.tabla.delete(*self.tabla.get_children())
        ruta = self.ruta_actual.get()
        txt = self.busqueda.get().lower()

        for item in sorted(os.listdir(ruta)):
            if txt in item.lower():
                fp = os.path.join(ruta, item)
                if item != "Vault":
                    s = os.stat(fp)
                    fecha = time.strftime('%d/%m/%Y', time.localtime(s.st_mtime))
                    tam = "--" if os.path.isdir(fp) else f"{s.st_size//1024} KB"
                    prefijo = "📁 " if os.path.isdir(fp) else "📄 "
                    self.tabla.insert("", "end", values=(f"{prefijo}{item}", tam, fecha))

    def on_tree_select(self, e):
        item = self.tree_dir.selection()
        if item:
            val = self.tree_dir.item(item, "values")
            if val:
                self.ruta_actual.set(val[0])
                self.actualizar_lista()

    def cargar_arbol_inicial(self):
        home = os.path.expanduser("~")
        node = self.tree_dir.insert("", "end", text="Mi PC", values=[home], open=True)
        for d in sorted(os.listdir(home)):
            full = os.path.join(home, d)
            if os.path.isdir(full):
                self.tree_dir.insert(node, "end", text=f"  {d}", values=[full])

    def on_doble_clic(self, e):
        item = self.tabla.focus()
        if not item:
            return
        nombre = self.tabla.item(item, "values")[0][2:]
        ruta = os.path.join(self.ruta_actual.get(), nombre)

        if os.path.isdir(ruta):
            self.ruta_actual.set(ruta)
            self.actualizar_lista()
        else:
            self.abrir_archivo(ruta)

    def abrir_archivo(self, ruta):
        try:
            sistema = platform.system()
            if sistema == "Windows":
                os.startfile(ruta)
            elif sistema == "Darwin":
                subprocess.call(["open", ruta])
            else:
                subprocess.call(["xdg-open", ruta])
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def crear(self):
        f = filedialog.asksaveasfilename(initialdir=self.ruta_actual.get())
        if f:
            open(f, 'w').close()
            self.actualizar_lista()

    def borrar(self):
        item = self.tabla.focus()
        if not item:
            return
        nombre = self.tabla.item(item, "values")[0][2:]
        ruta = os.path.join(self.ruta_actual.get(), nombre)
        if messagebox.askyesno("Blaster", f"¿Eliminar {nombre}?"):
            if os.path.isdir(ruta):
                shutil.rmtree(ruta)
            else:
                os.remove(ruta)
            self.actualizar_lista()

    def hacer_zip(self):
        item = self.tabla.focus()
        if not item:
            return
        nombre = self.tabla.item(item, "values")[0][2:]
        origen = os.path.join(self.ruta_actual.get(), nombre)
        dest = filedialog.asksaveasfilename(defaultextension=".zip")
        if dest:
            if os.path.isdir(origen):
                shutil.make_archive(dest.replace(".zip",""), 'zip', origen)
            else:
                with zipfile.ZipFile(dest, 'w') as z:
                    z.write(origen, arcname=nombre)

if __name__ == "__main__":
    root = tk.Tk()
    app = BlasterFile(root)
    root.mainloop()





